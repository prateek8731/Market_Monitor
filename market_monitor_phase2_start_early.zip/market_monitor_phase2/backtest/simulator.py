import pandas as pd, numpy as np
def sma_signal(df, short=10, long=50):
    df = df.copy()
    df["s_short"] = df["close"].rolling(short).mean()
    df["s_long"] = df["close"].rolling(long).mean()
    df["signal"] = 0
    df.loc[df["s_short"] > df["s_long"], "signal"] = 1
    df.loc[df["s_short"] < df["s_long"], "signal"] = -1
    return df

class Backtester:
    def __init__(self, initial_capital=100000.0):
        self.initial_capital = initial_capital

    def run_signals(self, df, strategy_func):
        """
        df: DataFrame with date, close, volume
        strategy_func: function(df) -> df with 'signal' column (1 buy, -1 sell, 0 hold)
        Returns equity curve and summary statistics.
        """
        df = df.copy().reset_index(drop=True)
        df = df[['date','close','volume']].dropna().reset_index(drop=True)
        df = strategy_func(df)
        # simple execution: enter at next open (assume close==price)
        cash = self.initial_capital
        position = 0.0
        equity = []
        shares = 0.0
        for i, row in df.iterrows():
            price = row["close"]
            sig = row.get("signal", 0)
            # simple execution logic
            if sig == 1 and cash > price:
                # buy as many shares as possible with 10% capital per signal (risk control)
                allocation = 0.10 * cash
                qty = allocation // price
                if qty > 0:
                    cash -= qty * price
                    shares += qty
            elif sig == -1 and shares > 0:
                # sell all shares
                cash += shares * price
                shares = 0
            total = cash + shares * price
            equity.append(total)
        returns = pd.Series(equity).pct_change().fillna(0)
        cum_return = (equity[-1] / self.initial_capital - 1) * 100.0 if equity else 0.0
        summary = {"final_capital": equity[-1] if equity else self.initial_capital, "cum_return_pct": cum_return, "max_drawdown_pct": self.max_drawdown(returns)}
        return {"equity_curve": equity, "summary": summary}

    def max_drawdown(self, returns):
        # approximate via cumulative returns
        cum = (1 + returns).cumprod()
        peak = cum.cummax()
        dd = (cum - peak) / peak
        return float(dd.min()*100.0)