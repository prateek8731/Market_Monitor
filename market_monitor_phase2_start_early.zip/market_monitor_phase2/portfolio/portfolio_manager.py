import sqlite3, os, pandas as pd, time
DB = os.path.join(os.getcwd(), "portfolio.db")
class PortfolioManager:
    def __init__(self, db_path=DB):
        self.db = db_path
        self._ensure_db()

    def _ensure_db(self):
        conn = sqlite3.connect(self.db)
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS account (id INTEGER PRIMARY KEY, cash REAL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY, ts TEXT, symbol TEXT, side TEXT, qty INTEGER, price REAL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS positions (symbol TEXT PRIMARY KEY, qty INTEGER, avg_price REAL)""")
        conn.commit()
        # init account if empty
        c.execute("SELECT COUNT(*) FROM account")
        if c.fetchone()[0] == 0:
            c.execute("INSERT INTO account (cash) VALUES (?)", (100000.0,))
            conn.commit()
        conn.close()

    def get_balance(self):
        conn = sqlite3.connect(self.db)
        c = conn.cursor()
        c.execute("SELECT cash FROM account LIMIT 1")
        bal = c.fetchone()[0]
        conn.close()
        return bal

    def place_order(self, symbol, side, qty, price):
        conn = sqlite3.connect(self.db)
        c = conn.cursor()
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        # record trade
        c.execute("INSERT INTO trades (ts,symbol,side,qty,price) VALUES (?,?,?,?,?)", (ts,symbol,side,qty,price))
        # update positions and cash
        c.execute("SELECT qty, avg_price FROM positions WHERE symbol=?", (symbol,))
        row = c.fetchone()
        if side.upper()=="BUY":
            cost = qty*price
            # deduct cash
            c.execute("UPDATE account SET cash = cash - ? WHERE id=1", (cost,))
            if row:
                new_qty = row[0] + qty
                new_avg = (row[0]*row[1] + qty*price)/new_qty
                c.execute("UPDATE positions SET qty=?, avg_price=? WHERE symbol=?", (new_qty,new_avg,symbol))
            else:
                c.execute("INSERT INTO positions (symbol,qty,avg_price) VALUES (?,?,?)", (symbol,qty,price))
        else:
            # SELL
            if row:
                new_qty = row[0] - qty
                proceed = qty*price
                c.execute("UPDATE account SET cash = cash + ? WHERE id=1", (proceed,))
                if new_qty<=0:
                    c.execute("DELETE FROM positions WHERE symbol=?", (symbol,))
                else:
                    c.execute("UPDATE positions SET qty=? WHERE symbol=?", (new_qty,symbol))
        conn.commit()
        conn.close()

    def list_positions(self):
        conn = sqlite3.connect(self.db)
        df = pd.read_sql_query("SELECT * FROM positions", conn)
        conn.close()
        return df

    def list_trades(self):
        conn = sqlite3.connect(self.db)
        df = pd.read_sql_query("SELECT * FROM trades ORDER BY ts DESC LIMIT 200", conn)
        conn.close()
        return df