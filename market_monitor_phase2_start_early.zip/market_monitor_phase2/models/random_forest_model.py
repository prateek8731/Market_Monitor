import pandas as pd, numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error

class RFModel:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)

    def featurize(self, df, horizon=1):
        df = df.copy().sort_values("date").reset_index(drop=True)
        df["close"] = df["close"].astype(float)
        for lag in range(1,6):
            df[f"lag_{lag}"] = df["close"].shift(lag)
        df["ret_1"] = df["close"].pct_change().fillna(0)
        df["ma_10"] = df["close"].rolling(10).mean().fillna(method='bfill')
        df["ma_50"] = df["close"].rolling(50).mean().fillna(method='bfill')
        df["vol_ma_10"] = df["volume"].rolling(10).mean().fillna(0)
        df["target"] = df["close"].shift(-horizon)
        df = df.dropna().reset_index(drop=True)
        X = df[[c for c in df.columns if c.startswith("lag_")] + ["ret_1","ma_10","ma_50","vol_ma_10"]]
        y = df["target"]
        return X, y, df

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)

    def run_full_pipeline(self, df, horizon=1):
        X, y, df_feat = self.featurize(df, horizon=horizon)
        if X.empty:
            return {"metrics": {}, "pred_pct": 0.0, "recent_series": df}
        split = int(0.8 * len(X))
        X_train, X_test = X[:split], X[split:]
        y_train, y_test = y[:split], y[split:]
        self.fit(X_train, y_train)
        preds = self.predict(X_test)
        rmse = mean_squared_error(y_test, preds, squared=False)
        mae = mean_absolute_error(y_test, preds)
        # predict last row
        lastX = X.iloc[[-1]]
        pred_price = float(self.predict(lastX)[0])
        curr_price = float(df_feat["close"].iloc[-1])
        pred_pct = (pred_price - curr_price)/curr_price*100.0
        return {"metrics":{"rmse":rmse,"mae":mae}, "pred_pct": pred_pct, "recent_series": df_feat[["date","close"]].tail(200)}