# Placeholders for Darts and NeuralProphet integrations.
# Installing these packages is optional and they are heavy (Darts uses PyTorch/TF backends).
# If you want to enable them, install specified extras in requirements and uncomment usage in app.py