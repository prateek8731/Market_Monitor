# LSTM model wrapper (uses TensorFlow/Keras if installed). This is optional and will only run if TF is available.
import pandas as pd, numpy as np
try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import LSTM, Dense, Dropout
    TF_AVAILABLE = True
except Exception as e:
    TF_AVAILABLE = False

class LSTMModel:
    def __init__(self, lookback=20):
        if not TF_AVAILABLE:
            raise RuntimeError("TensorFlow not installed. Install tensorflow to use LSTMModel.")
        self.lookback = lookback
        self.model = None

    def prepare(self, series):
        data = series.values
        X, y = [], []
        for i in range(len(data)-self.lookback):
            X.append(data[i:i+self.lookback])
            y.append(data[i+self.lookback])
        X = np.array(X)
        y = np.array(y)
        X = X.reshape((X.shape[0], X.shape[1], 1))
        return X, y

    def fit(self, series, epochs=10, batch_size=16):
        X, y = self.prepare(series)
        model = Sequential()
        model.add(LSTM(64, input_shape=(X.shape[1], X.shape[2])))
        model.add(Dropout(0.2))
        model.add(Dense(1))
        model.compile(optimizer='adam', loss='mse')
        model.fit(X, y, epochs=epochs, batch_size=batch_size, verbose=0)
        self.model = model

    def predict_next(self, series):
        if self.model is None:
            raise RuntimeError("Model not trained")
        X, _ = self.prepare(series)
        last = X[-1].reshape(1, X.shape[1], X.shape[2])
        return float(self.model.predict(last)[0][0])